# 배포 가이드 — GitHub(scare.git) + Vercel

이 컨테이너는 외부 네트워크(git push, GitHub API)에 접근할 수 없어서, 제가 직접
`https://github.com/namonamho88-ui/scare.git` 에 푸시할 수는 없습니다. 아래 순서대로
직접 연결해 주세요. (파일은 이미 다 준비되어 있습니다 — 복사/붙여넣기만 하면 됩니다)

## 1. 저장소에 파일 반영
```bash
git clone https://github.com/namonamho88-ui/scare.git
cd scare
# 아래 4개 파일을 다운로드한 폴더 내용으로 교체
#   index.html
#   vercel.json
#   api/ai.js   (새 폴더)
#   .env.example
git add -A
git commit -m "fix: remove Tailwind CDN & vercel catch-all rewrite, add server-side Gemini proxy"
git push origin main
```
기존 `app.js` / `style.css`는 더 이상 필요 없습니다 — 모든 CSS/JS가 `index.html` 하나에
인라인으로 들어있어서, 외부 파일 로딩 실패나 CSP 문제가 애초에 발생할 수 없는 구조입니다.
(남겨둬도 무해하지만, 정리하려면 삭제하셔도 됩니다.)

## 2. Vercel에 GitHub 저장소 연결
1. https://vercel.com → **Add New → Project**
2. `namonamho88-ui/scare` 저장소 Import
3. Framework Preset: **Other** (빌드 명령어 없음, Output Directory 비워둠)

## 3. AI 기능을 위한 서버 환경변수 설정 (중요)
Vercel 프로젝트 → **Settings → Environment Variables**
| Key | Value |
|---|---|
| `GEMINI_API_KEY` | 발급받은 Google Gemini API 키 |

이 키는 브라우저로 절대 전송되지 않고 `/api/ai` 서버리스 함수 안에서만 사용됩니다.
환경변수 저장 후 **Redeploy**가 필요합니다.

## 4. 배포 후 확인
- 앱 우측 상단 **AI 모델 배지 클릭 → 연결 테스트** 버튼으로 `/api/ai` ↔ Gemini 통신 확인
- 실패 시: Vercel → 프로젝트 → Deployments → 해당 함수 로그(`/api/ai`)에서 에러 메시지 확인
