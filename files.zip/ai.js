// /api/ai — server-side Gemini proxy.
// The API key lives only in the Vercel project's environment variables
// (GEMINI_API_KEY), so it is never sent to or stored in the browser.

const ALLOWED_MODELS = ['gemini-2.0-flash', 'gemini-1.5-flash', 'gemini-1.5-pro'];

module.exports = async (req, res) => {
  res.setHeader('Content-Type', 'application/json; charset=utf-8');

  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed. Use POST.' });
    return;
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    res.status(500).json({
      error: 'SERVER_KEY_MISSING',
      message: 'Vercel 프로젝트에 GEMINI_API_KEY 환경변수가 설정되어 있지 않습니다.'
    });
    return;
  }

  let body = req.body;
  if (typeof body === 'string') {
    try { body = JSON.parse(body); } catch (e) { body = {}; }
  }
  body = body || {};

  const prompt = typeof body.prompt === 'string' ? body.prompt.trim() : '';
  if (!prompt) {
    res.status(400).json({ error: 'BAD_REQUEST', message: 'prompt 값이 필요합니다.' });
    return;
  }

  const model = ALLOWED_MODELS.includes(body.model) ? body.model : 'gemini-2.0-flash';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

  try {
    const upstream = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ role: 'user', parts: [{ text: prompt.slice(0, 12000) }] }],
        generationConfig: { temperature: 0.4, maxOutputTokens: 1024 }
      })
    });

    const data = await upstream.json().catch(() => null);

    if (!upstream.ok) {
      res.status(upstream.status).json({
        error: 'UPSTREAM_ERROR',
        message: (data && data.error && data.error.message) || `Gemini API 오류 (HTTP ${upstream.status})`
      });
      return;
    }

    const text =
      (data &&
        data.candidates &&
        data.candidates[0] &&
        data.candidates[0].content &&
        data.candidates[0].content.parts &&
        data.candidates[0].content.parts[0] &&
        data.candidates[0].content.parts[0].text) ||
      '';

    res.status(200).json({ text, model });
  } catch (err) {
    res.status(502).json({
      error: 'FETCH_FAILED',
      message: '외부 AI 서버와 통신에 실패했습니다.',
      detail: String((err && err.message) || err)
    });
  }
};
